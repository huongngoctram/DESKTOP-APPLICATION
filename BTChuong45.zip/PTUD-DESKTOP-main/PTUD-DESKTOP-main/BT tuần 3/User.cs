﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT_tuần_3
{
    public class UserAccount
    {
        public string Username { get; set; }
        public string Role { get; set; } // "Admin" or "User"

        public UserAccount(string username, string role)
        {
            Username = username;
            Role = role;
        }
    }
}
